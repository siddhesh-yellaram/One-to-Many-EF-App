﻿using OnetoManyEFApp.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnetoManyEFApp
{
    class Program
    {
        static void Main(string[] args)
        {
            AurionProDBContext db = new AurionProDBContext();
            //Department d = new Department {DName = "IT", Location = "Mumbai"};
            //Department d1 = new Department { DName = "Sales", Location = "Pune" };
            Department d2 = new Department { DName = "HR", Location = "Mumbai" };
            //Employee e1 = new Employee { EName = "Sid", Dept = d };
            //Employee e2 = new Employee { EName = "Jenny", Dept = d };
            //Employee e3 = new Employee { EName = "Emily" , Dept = d};
            //Employee e4 = new Employee { EName = "Fary" , Dept = d};
            //Employee e5 = new Employee { EName = "Rachel", Dept = d1};
            //Employee e6 = new Employee { EName = "Bam" , Dept = d1};
            //Employee e7 = new Employee { EName = "Khun" , Dept = d1};
            Employee e8 = new Employee { EName = "Yuri", Dept = d2 };
            Employee e9 = new Employee { EName = "Rak", Dept = d2 };
            Employee e10 = new Employee { EName = "Wangman", Dept = d2 };
            //d.Emps = new List<Employee> { e1, e2, e3, e4 };
            //d1.Emps = new List<Employee> { e5, e6, e7 };
            d2.Emps = new List<Employee> { e8, e9, e10 };
            //db.Employees.Add(e1);
            //db.Employees.Add(e2);
            //db.Employees.Add(e3);
            //db.Employees.Add(e4);
            //db.Employees.Add(e5);
            //db.Employees.Add(e6);
            //db.Employees.Add(e7);
            //db.Employees.Add(e8);
            //db.Employees.Add(e9);
            //db.Employees.Add(e10);
            //db.Departments.AddRange(new List<Department> { d, d1 });
            //db.Departments.Add(d2);
            //Console.WriteLine(e10);
            //Console.WriteLine(d2);
            db.SaveChanges();

            
        }
    }
}
