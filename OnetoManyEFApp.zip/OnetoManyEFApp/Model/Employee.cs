﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnetoManyEFApp.Model
{
    class Employee
    {
        [Key]
        public int ENo { get; set; }
        public string EName { get; set; }
        public Department Dept { get; set; }
        public override string ToString()
        {
            return EName + ": " + Dept.DName;
        }
    }
}
