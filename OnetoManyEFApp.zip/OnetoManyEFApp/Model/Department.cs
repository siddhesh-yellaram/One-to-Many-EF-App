﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnetoManyEFApp.Model
{
    class Department
    {
        [Key]
        public int DNo { get; set; }
        public string DName { get; set; }
        public string Location { get; set; }
        public virtual List<Employee> Emps { get; set; }

        public override string ToString()
        {
            string emps = "";
            foreach (Employee e in Emps)
            {
                emps = emps + e.EName + ", ";
            }
            return DName + Environment.NewLine + emps;
        }
    }
}
