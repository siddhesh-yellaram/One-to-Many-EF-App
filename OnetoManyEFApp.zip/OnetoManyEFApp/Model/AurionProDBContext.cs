﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnetoManyEFApp.Model
{
    class AurionProDBContext:DbContext
    {
        public AurionProDBContext() : base("aurionProDB") { }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Department> Departments { get; set; }
    }
}
